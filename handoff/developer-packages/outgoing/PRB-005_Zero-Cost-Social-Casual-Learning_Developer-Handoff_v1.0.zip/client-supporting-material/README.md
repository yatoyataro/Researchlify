# Client-Facing Supporting Material (Package B: ART-012 through ART-017)

These files are plain-language stakeholder communications derived from the approved technical artifacts.
They are **supplementary context only** and do **not** replace `primary-handoff/ART-011-package-a-technical-handoff.md` or `ART-007`..`ART-009` as engineering specifications.
